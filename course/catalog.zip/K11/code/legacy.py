# BUG: reports highest CLIP-like score as calibrated probability of truth
confidence=top_score
