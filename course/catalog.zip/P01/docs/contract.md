Обязательные поля: customer_id (str), age (int), income (float), label (int). Необязательные новые поля разрешены только явно.
