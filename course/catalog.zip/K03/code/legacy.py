import numpy as np
ids=list(range(10))
np.random.shuffle(ids)  # BUG: seed and generator not passed
print(ids[:3])
