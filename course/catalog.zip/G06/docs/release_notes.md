# Release 0.4
- PR-11: improved dataset validation
