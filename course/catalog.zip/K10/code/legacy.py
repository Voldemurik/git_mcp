# BUG: returns only input_ids, without attention_mask
encoded=tokenizer(texts, padding=True, truncation=False)
