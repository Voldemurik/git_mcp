import numpy as np
prices=np.array([[100,110,120],[200,180,220],[50,60,70]])
discounts=np.array([.10,0,.20])
net=prices*(1-discounts[:,None])  # BUG: discounts applied to rows
print(net)
