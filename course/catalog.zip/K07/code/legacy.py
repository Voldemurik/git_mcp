from sklearn.model_selection import KFold
cv=KFold(n_splits=3)  # BUG: ignores customer_id
