"""Персональный MCP-сервер варианта K06 (pandas: пропуски и денежные типы).

Файл создан SmartClass при выдаче задания. Инструменты и их назначения уже
определены. Студент реализует ТОЛЬКО предметную функцию audit_missing_values(),
а также при необходимости улучшает отчёт и логику. Готовые функции
чтения/сохранения и MCP-транспорт менять необязательно.

Запуск: python -m student.own_server
Для сервера stdout — протокол; для отладки используйте stderr.
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CASE_DIR = ROOT / "case"
OUTPUT_DIR = ROOT / "llm-mcp-result" / "outputs"
CASE_ID = "K06"
# Читаем ТОЛЬКО перечисленные входные файлы; никакого произвольного пути.
INPUT_FILES = ['data/sales.csv', 'docs/semantics.md', 'data/schema.json', 'data/special_cases.csv', 'code/legacy.py']


def _read_inputs() -> dict:
    """Готовая безопасная загрузка входных файлов из case/."""
    data = {}
    for rel_path in INPUT_FILES:
        path = (CASE_DIR / rel_path).resolve()
        if not path.is_relative_to(CASE_DIR.resolve()) or not path.is_file():
            raise ValueError("Недоступный файл задания: " + rel_path)
        if path.suffix == ".csv":
            with path.open(encoding="utf-8-sig", newline="") as handle:
                data[rel_path] = list(csv.DictReader(handle))
        elif path.suffix == ".json":
            data[rel_path] = json.loads(path.read_text(encoding="utf-8"))
        else:
            # Документы и примеры Python читаем как ТЕКСТ, не исполняем!
            data[rel_path] = path.read_text(encoding="utf-8")
    return {"case_id": CASE_ID, "sources": list(INPUT_FILES), "data": data}


def _write_output(filename: str, content: str) -> None:
    """Готовая запись в llm-mcp-result/outputs/, без обхода путей."""
    if filename not in {"result.json", "report.md"}:
        raise ValueError("Запрещено записывать такой файл: " + filename)
    report_dir = ROOT / "llm-mcp-result"
    if report_dir.is_symlink() or OUTPUT_DIR.is_symlink():
        raise ValueError("Символические ссылки для результатов запрещены")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    target = OUTPUT_DIR / filename
    if target.is_symlink() or not target.resolve().is_relative_to(OUTPUT_DIR.resolve()):
        raise ValueError("Запись за пределами outputs запрещена")
    target.write_text(content, encoding="utf-8")


def health_check() -> dict:
    """Проверка связи с сервером; не считается предметным инструментом."""
    return {"status": "ready", "case_id": CASE_ID}


def get_sales() -> dict:
    """прочитать продажи, пропуски и правила денежного поля. Вход: без аргументов; выход: case_id, sources, data."""
    return _read_inputs()


def audit_missing_values() -> dict:
    """разделить отсутствующие суммы и нули, проверить типы денег.

    Вход: без аргументов. Источники доступны через get_sales().
    Выход: JSON-словарь с полями case_id, status='completed',
    sources, result, checks, report_md. Содержание result: ID исключений, денежные итоги и ошибки подстановки нуля.
    Отчёт report_md — Markdown не короче 60 символов.
    """
    # TODO (K06): реализуйте вычисление/проверку по файлам из case/.
    # Вызывайте _read_inputs() или get_sales(), но не изменяйте исходники.
    # Никаких тяжёлых ML-моделей и внешних зависимостей не требуется.
    # Пример структуры возвращаемого объекта (не готовое решение):
    # {"case_id": CASE_ID, "status": "completed", "sources": [...],
    #  "result": {...}, "checks": {"domain_passed": True},
    #  "report_md": "# Отчёт\n..."}
    raise NotImplementedError("Реализуйте audit_missing_values() для варианта K06")


def save_result() -> dict:
    """Сохранить проверенный предметный результат в outputs/result.json и report.md.

    Выход: status='saved' и список двух файлов. Пока audit_missing_values()
    не реализована, этот инструмент ничего не сохраняет.
    """
    result = audit_missing_values()
    if not isinstance(result, dict) or result.get("case_id") != CASE_ID:
        raise ValueError("Анализ должен вернуть объект со своим case_id")
    if result.get("status") != "completed":
        raise ValueError("Нельзя сохранять незавершённый анализ")
    if not isinstance(result.get("result"), dict) or not result["result"]:
        raise ValueError("В результате нет содержательных данных")
    if not isinstance(result.get("sources"), list) or not result["sources"]:
        raise ValueError("В результате нет источников")
    if not isinstance(result.get("checks"), dict) or not result["checks"]:
        raise ValueError("В результате нет проверок")
    report_md = result.get("report_md", "")
    if not isinstance(report_md, str) or len(report_md.strip()) < 60:
        raise ValueError("report_md должен содержать содержательный отчёт")
    public_result = {k: v for k, v in result.items() if k != "report_md"}
    # Не сохраняем ни одного файла, пока полностью не проверили контракт.
    _write_output("result.json", json.dumps(public_result, ensure_ascii=False, indent=2) + "\n")
    _write_output("report.md", report_md.rstrip() + "\n")
    return {"status": "saved", "files": ["outputs/result.json", "outputs/report.md"]}


# Регистрация 4 реальных MCP-инструментов: health + 3 предметных.
# Протокольный каркас уже предоставлен; его необязательно переписывать.
TOOLS = {
    "health_check": (health_check, health_check.__doc__),
    "get_sales": (get_sales, get_sales.__doc__),
    "audit_missing_values": (audit_missing_values, audit_missing_values.__doc__),
    "save_result": (save_result, save_result.__doc__),
}


def _dispatch(method: str, params: dict) -> dict:
    if method == "initialize":
        return {"protocolVersion": "2025-06-18",
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "student-K06", "version": "0.4"}}
    if method == "ping":
        return {}
    if method == "tools/list":
        return {"tools": [{"name": name, "description": desc,
                           "inputSchema": {"type": "object", "properties": {}, "required": []}}
                          for name, (_, desc) in TOOLS.items()]}
    if method == "tools/call":
        name = params.get("name")
        arguments = params.get("arguments", {})
        if name not in TOOLS or not isinstance(arguments, dict) or arguments:
            return {"isError": True, "content": [{"type": "text", "text": "Неверный инструмент или аргументы"}]}
        try:
            answer = TOOLS[name][0]()
            return {"isError": False, "content": [{"type": "text", "text": json.dumps(answer, ensure_ascii=False)}]}
        except (NotImplementedError, ValueError, OSError, TypeError, KeyError) as exc:
            return {"isError": True, "content": [{"type": "text", "text": f"{type(exc).__name__}: {str(exc)[:180]}"}]}
    raise ValueError("Неизвестный MCP метод: " + method)


def main() -> None:
    # Построчный stdio JSON-RPC совместим с course.protocol.MCPStdio.
    # Ничего не печатайте в stdout, кроме ответов на запросы JSON-RPC.
    for line in sys.stdin:
        try:
            request = json.loads(line)
            if not isinstance(request, dict) or request.get("jsonrpc") != "2.0":
                continue
            if request.get("method") == "notifications/initialized" or "id" not in request:
                continue
            try:
                response = {"jsonrpc": "2.0", "id": request["id"],
                            "result": _dispatch(request.get("method", ""), request.get("params") or {})}
            except (ValueError, TypeError) as exc:
                response = {"jsonrpc": "2.0", "id": request["id"],
                            "error": {"code": -32601, "message": str(exc)[:180]}}
            sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
            sys.stdout.flush()
        except (ValueError, TypeError):
            continue


if __name__ == "__main__":
    main()
