import pandas as pd
df=pd.read_csv("data/sales.csv").fillna(0) # BUG: missing is not zero
