import pandas as pd
df=pd.read_csv("data/events.csv")
df["month"]=df["ts_utc"].str[:7] # BUG
