import pandas as pd
events=pd.read_csv("data/events.csv")
accounts=pd.read_csv("data/accounts.csv")
print(events.merge(accounts,on="account_id")["amount"].sum())
