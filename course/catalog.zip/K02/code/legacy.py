import numpy as np
raw=np.array([120,110,70],dtype=np.int8)
print(raw.astype(np.int8).cumsum(dtype=np.int8)[-1])
