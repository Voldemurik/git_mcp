from sklearn.preprocessing import StandardScaler
# BUG: uses train+validation while fitting scaler
scaler=StandardScaler().fit([[1],[2],[3],[101],[102],[103]])
