Старая процедура: concat(train, validation) → StandardScaler.fit_transform → split → score. Это утечка.
