from sklearn.preprocessing import OneHotEncoder
enc=OneHotEncoder(sparse=False) # BUG for newer sklearn versions
