# Восстановление истории для G01

Файл `fixture.bundle` — настоящий Git bundle с двумя коммитами. Восстановить в отдельную папку:

```bash
git clone fixture.bundle fixture-repo
cd fixture-repo
python -m pytest -q
```

Команда `python -m pytest` требует установленного pytest; для просмотра истории достаточно `git log -p`.

**Не исправлять файлы tests/**. Исправление ожидается в `app/classifier.py`.
